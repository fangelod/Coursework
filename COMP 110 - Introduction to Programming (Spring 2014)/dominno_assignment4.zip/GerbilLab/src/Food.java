
public class Food {

	private Integer types;
	private String foodName;
	private Integer maxAmount;
	public Food() {
	}
	public Integer getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(int i) {
		this.maxAmount = i;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public Integer getTypes() {
		return types;
	}
	public void setTypes(Integer types) {
		this.types = types;
	}
}
