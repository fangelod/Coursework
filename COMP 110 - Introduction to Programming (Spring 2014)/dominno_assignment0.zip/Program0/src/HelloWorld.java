/******************************************************************
 * Program or Assignment #: Assignment0
 *
 * Programmer: Franz Dominno
 *
 * Due Date: Friday, January 17, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program, when run, prints out the quote "Hello World"
 *
 * Input: None
 *
 * Output: Prints out the quote "Hello World"
 *
 ******************************************************************/
public class HelloWorld 
{
	public static void main (String[] args)
	{
		System.out.println("Hello World");
	}
}
